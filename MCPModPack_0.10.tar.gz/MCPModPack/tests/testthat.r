library(testthat)
test_check("MCPModPack")